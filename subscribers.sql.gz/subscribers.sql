-- Adminer 4.8.1 MySQL 5.7.32 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP DATABASE IF EXISTS `subscriptions`;
CREATE DATABASE `subscriptions` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `subscriptions`;

DROP TABLE IF EXISTS `subscribers`;
CREATE TABLE `subscribers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `subscribers` (`id`, `email`, `timestamp`) VALUES
(1,	'kristaps.zakis@gmail.com',	'0000-00-00 00:00:00'),
(40,	'kristaps.zakis@gmail.com',	'2021-12-02 10:58:52'),
(41,	'kristaps.zakis@gmail.com',	'2021-12-02 10:58:55'),
(42,	'janis.berzins@inbox.lv',	'2021-12-02 10:59:12'),
(43,	'janis.berzins@inbox.lv',	'2021-12-02 10:59:14'),
(44,	'janis.berzins@yahoo.com',	'2021-12-02 10:59:23'),
(45,	'janis.berzins@yahoo.net',	'2021-12-02 10:59:35');

-- 2021-12-02 11:02:11
